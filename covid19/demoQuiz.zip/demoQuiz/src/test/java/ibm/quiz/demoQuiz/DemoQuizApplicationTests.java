package ibm.quiz.demoQuiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
