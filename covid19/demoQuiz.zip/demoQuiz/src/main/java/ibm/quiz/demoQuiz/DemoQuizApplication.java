package ibm.quiz.demoQuiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoQuizApplication.class, args);
	}

}
